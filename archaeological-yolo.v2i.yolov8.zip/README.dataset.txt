# archaeological-yolo > 2025-12-26 2:24pm
https://universe.roboflow.com/project-p0uuv/archaeological-yolo

Provided by a Roboflow user
License: CC BY 4.0

